from tkinter import *

window = Tk()

window.mainloop()